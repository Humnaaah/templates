<?php if ( ! empty( $button_params ) ) { ?>
	<div class="qodef-m-button qodef-qi-clear">
		<?php echo QiAddonsForElementor_Button_Shortcode::call_shortcode( $button_params ); ?>
	</div>
<?php } ?>
