<?php if ( ! empty( $shortcode['video'] ) ) : ?>
	<a href="<?php echo esc_url( $shortcode['video'] ); ?>" target="_blank"><?php esc_html_e( 'Video', 'qi-addons-for-elementor' ); ?></a>
<?php endif; ?>
