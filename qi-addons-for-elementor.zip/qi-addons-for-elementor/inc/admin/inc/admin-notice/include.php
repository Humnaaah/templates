<?php

require_once QI_ADDONS_FOR_ELEMENTOR_ADMIN_PATH . '/inc/admin-notice/class-qiaddonsforelementor-admin-notice.php';
