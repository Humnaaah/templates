<?php

include_once QI_ADDONS_FOR_ELEMENTOR_PLUGINS_PATH . '/wp-forms/shortcodes/wp-forms/class-qiaddonsforelementor-wp-forms-shortcode.php';
