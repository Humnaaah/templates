<div class="qodef-m-item swiper-slide">
	<?php echo qi_addons_for_elementor_get_list_shortcode_item_image( 'full', $image_id ); ?>
</div>
