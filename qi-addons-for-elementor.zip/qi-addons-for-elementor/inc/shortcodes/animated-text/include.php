<?php

include_once QI_ADDONS_FOR_ELEMENTOR_SHORTCODES_PATH . '/animated-text/class-qiaddonsforelementor-animated-text-shortcode.php';
