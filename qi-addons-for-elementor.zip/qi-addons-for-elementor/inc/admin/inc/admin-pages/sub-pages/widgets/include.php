<?php

require_once QI_ADDONS_FOR_ELEMENTOR_ADMIN_PATH . '/inc/admin-pages/sub-pages/widgets/class-qiaddonsforelementor-admin-page-widgets.php';
