<?php if ( ! empty( $subtitle ) ) { ?>
	<span class="qodef-m-subtitle">
		<?php echo esc_html( $subtitle ); ?>
	</span>
<?php } ?>
