<?php

include_once QI_ADDONS_FOR_ELEMENTOR_INC_PATH . '/masonry/helper.php';
