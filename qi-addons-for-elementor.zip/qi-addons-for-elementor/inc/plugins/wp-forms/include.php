<?php

include_once QI_ADDONS_FOR_ELEMENTOR_PLUGINS_PATH . '/wp-forms/class-qiaddonsforelementor-wp-forms.php';
