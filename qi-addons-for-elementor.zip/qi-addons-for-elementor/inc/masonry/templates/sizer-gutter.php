<?php if ( 'masonry' === $params ) { ?>
	<div class="qodef-qi-grid-masonry-sizer"></div>
<?php } ?>
