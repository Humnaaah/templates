<?php if ( 'no' !== $slider_navigation ) { ?>
	<div class="swiper-button-prev"><?php qi_addons_for_elementor_template_part( 'content', 'templates/parts/arrow-left', '', $params ); ?></div>
	<div class="swiper-button-next"><?php qi_addons_for_elementor_template_part( 'content', 'templates/parts/arrow-right', '', $params ); ?></div>
<?php } ?>
