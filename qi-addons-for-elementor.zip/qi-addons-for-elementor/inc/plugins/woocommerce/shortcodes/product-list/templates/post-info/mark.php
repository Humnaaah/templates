<?php

if ( 'yes' === $show_mark ) {
	// Hook to include product mark
	do_action( 'qi_addons_for_elementor_action_woo_product_mark_info' );
}
