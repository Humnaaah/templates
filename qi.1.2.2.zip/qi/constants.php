<?php

define( 'QI_ROOT', get_template_directory_uri() );
define( 'QI_ROOT_DIR', get_template_directory() );
define( 'QI_ASSETS_ROOT', QI_ROOT . '/assets' );
define( 'QI_ASSETS_ROOT_DIR', QI_ROOT_DIR . '/assets' );
define( 'QI_ASSETS_CSS_ROOT', QI_ASSETS_ROOT . '/css' );
define( 'QI_ASSETS_CSS_ROOT_DIR', QI_ASSETS_ROOT_DIR . '/css' );
define( 'QI_ASSETS_JS_ROOT', QI_ASSETS_ROOT . '/js' );
define( 'QI_ASSETS_JS_ROOT_DIR', QI_ASSETS_ROOT_DIR . '/js' );
define( 'QI_INC_ROOT', QI_ROOT . '/inc' );
define( 'QI_INC_ROOT_DIR', QI_ROOT_DIR . '/inc' );
