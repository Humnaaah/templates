<div class="qodef-m-title-holder">
	<?php qi_addons_for_elementor_template_part( 'shortcodes/how-to', 'templates/parts/subtitle', '', $params ); ?>
	<?php qi_addons_for_elementor_template_part( 'shortcodes/how-to', 'templates/parts/title', '', $params ); ?>
	<?php qi_addons_for_elementor_template_part( 'shortcodes/how-to', 'templates/parts/text', '', $params ); ?>
</div>
