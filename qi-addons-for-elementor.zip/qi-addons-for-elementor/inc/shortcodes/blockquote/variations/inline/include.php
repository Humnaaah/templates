<?php

include_once QI_ADDONS_FOR_ELEMENTOR_SHORTCODES_PATH . '/blockquote/variations/inline/helper.php';
