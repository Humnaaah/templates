<?php if ( 'yes' === $enable_numbered  ) { ?>
	<span class="qodef-e-number">
		<?php echo esc_html( $number ); ?>
	</span>
	<?php
}
