<?php

include_once QI_ADDONS_FOR_ELEMENTOR_INC_PATH . '/blog/shortcodes/blog-slider/variations/side-image/side-image.php';
