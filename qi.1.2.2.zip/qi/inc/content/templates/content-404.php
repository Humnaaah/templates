<main id="qodef-page-content">
	<?php
	// Include 404 template
	qi_template_part( '404', 'templates/404' );
	?>
</main>
