<div class="<?php echo esc_attr( $item_classes ); ?>">
	<?php echo qi_addons_for_elementor_get_list_shortcode_item_image( $images_proportion, $image_id, intval( $custom_image_width ), intval( $custom_image_height ) ); ?>
</div>
