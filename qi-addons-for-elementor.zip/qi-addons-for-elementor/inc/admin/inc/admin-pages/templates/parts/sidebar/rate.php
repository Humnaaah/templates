<div class="qodef-admin-sidebar-box qodef-rate-box">
	<div class="qodef-admin-sidebar-box-content">
		<h3><?php esc_html_e( 'Rate Qi Addons', 'qi-addons-for-elementor' ); ?></h3>
		<p><?php esc_html_e( 'Let us know about your experience with Qi Addons.', 'qi-addons-for-elementor' ); ?></p>
		<a class="qodef-btn qodef-btn-simple" href="https://wordpress.org/plugins/qi-addons-for-elementor/#reviews" target="_blank"><?php esc_html_e( 'Rate US', 'qi-addons-for-elementor' ); ?></a>
	</div>
</div>
