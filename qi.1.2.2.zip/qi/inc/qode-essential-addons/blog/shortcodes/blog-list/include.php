<?php

include_once QI_INC_ROOT_DIR . '/qode-essential-addons/blog/shortcodes/blog-list/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
