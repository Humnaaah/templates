<?php

include_once QI_ADDONS_FOR_ELEMENTOR_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-below-with-hover/info-below-with-hover.php';
