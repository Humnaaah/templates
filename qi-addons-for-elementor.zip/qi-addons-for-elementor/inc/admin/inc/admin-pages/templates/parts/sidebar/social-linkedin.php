<div class="qodef-social-box">
	<a href="https://www.linkedin.com/company/qode-themes/" target="_blank">
		<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="25.999px" height="25px" viewBox="0 0 25.999 25" enable-background="new 0 0 25.999 25" xml:space="preserve">
			<g>
				<path fill="#CACACA" d="M25.999,12.628c0-1.189-0.935-2.153-2.088-2.153h-4.828h-2.158c-0.053-0.237-0.076-0.49-0.03-0.752
					c0.119-0.686,0.557-2.049,1.26-3.315c0.517-0.931,0.725-5.352-0.226-6.027c-0.949-0.674-2.25-0.427-2.904,0.552l-1.182,4.449
					l-2.347,3.512c-0.425,0.635-2.624,3.257-2.624,3.257v11.757L12.529,25h6.554h1.535c1.153,0,2.089-0.964,2.089-2.153
					c0-0.277-0.056-0.541-0.148-0.784c0.915-0.229,1.596-1.073,1.596-2.086c0-0.628-0.264-1.188-0.679-1.58
					c0.96-0.195,1.684-1.064,1.684-2.111c0-0.634-0.27-1.197-0.691-1.591C25.349,14.441,25.999,13.617,25.999,12.628"/>
				<rect y="11.123" fill="#CACACA" width="7.613" height="13.877"/>
			</g>
		</svg>
		<span><?php esc_html_e( 'LinkedIn', 'qi-addons-for-elementor' ); ?></span>
	</a>
</div>
