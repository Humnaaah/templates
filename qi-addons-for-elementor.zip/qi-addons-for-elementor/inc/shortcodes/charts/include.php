<?php

include_once QI_ADDONS_FOR_ELEMENTOR_SHORTCODES_PATH . '/charts/class-qiaddonsforelementor-charts-shortcode.php';
