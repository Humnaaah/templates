import React from 'react'

const Footer = () =>{
    return <div className='footer'> <p> Colored Strategies</p></div>
}


export default Footer