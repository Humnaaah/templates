<?php

include_once QI_ADDONS_FOR_ELEMENTOR_SHORTCODES_PATH . '/graphs/class-qiaddonsforelementor-graphs-shortcode.php';
