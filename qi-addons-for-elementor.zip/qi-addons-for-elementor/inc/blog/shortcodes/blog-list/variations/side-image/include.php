<?php

include_once QI_ADDONS_FOR_ELEMENTOR_INC_PATH . '/blog/shortcodes/blog-list/variations/side-image/side-image.php';
